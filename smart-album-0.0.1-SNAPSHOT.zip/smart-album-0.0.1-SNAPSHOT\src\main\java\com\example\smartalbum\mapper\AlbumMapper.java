package com.example.smartalbum.mapper;

import com.example.smartalbum.entity.Album;
import org.apache.ibatis.annotations.Mapper;
import java.util.List;

@Mapper
public interface AlbumMapper {
    Album selectById(Long id);
    List<Album> selectByUserId(Long userId);
    int insert(Album album);
    int update(Album album);
    int delete(Long id);
}