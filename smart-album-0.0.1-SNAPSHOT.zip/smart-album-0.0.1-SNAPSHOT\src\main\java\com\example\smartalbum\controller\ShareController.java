package com.example.smartalbum.controller;

import com.example.smartalbum.entity.Album;
import com.example.smartalbum.entity.ShareLink;
import com.example.smartalbum.entity.User;
import com.example.smartalbum.service.AlbumService;
import com.example.smartalbum.service.ShareService;
import com.example.smartalbum.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/shares")
public class ShareController {

    @Autowired
    private ShareService shareService;
    
    @Autowired
    private AlbumService albumService;
    
    @Autowired
    private UserService userService;
    
    private User getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        return userService.getUserByUsername(userDetails.getUsername());
    }
    
    @PostMapping("/generate")
    public ResponseEntity<ShareLink> generateShareLink(@RequestBody Map<String, Object> request) {
        User currentUser = getCurrentUser();
        
        Long albumId = Long.parseLong(request.get("albumId").toString());
        Integer expireDays = request.get("expireDays") != null ? Integer.parseInt(request.get("expireDays").toString()) : null;
        String password = (String) request.get("password");
        String permission = request.get("permission") != null ? (String) request.get("permission") : "view";
        
        Album album = albumService.getAlbumById(albumId);
        if (album == null) {
            return ResponseEntity.notFound().build();
        }
        
        ShareLink shareLink = shareService.generateShareLink(album, currentUser, expireDays, password, permission);
        return ResponseEntity.ok(shareLink);
    }
    
    @PostMapping("/validate")
    public ResponseEntity<Boolean> validateShareLink(@RequestBody Map<String, String> request) {
        String shareToken = request.get("shareToken");
        String password = request.get("password");
        
        boolean isValid = shareService.validateShareLink(shareToken, password);
        return ResponseEntity.ok(isValid);
    }
    
    @GetMapping("/token/{shareToken}")
    public ResponseEntity<ShareLink> getShareLinkByToken(@PathVariable String shareToken) {
        ShareLink shareLink = shareService.getShareLinkByToken(shareToken);
        return shareLink != null ? ResponseEntity.ok(shareLink) : ResponseEntity.notFound().build();
    }
    
    @PutMapping("/view-count/{shareLinkId}")
    public ResponseEntity<Void> updateViewCount(@PathVariable Long shareLinkId) {
        ShareLink shareLink = shareService.getShareLinkByToken(shareLinkId.toString());
        if (shareLink != null) {
            shareService.updateViewCount(shareLink);
        }
        return ResponseEntity.ok().build();
    }
    
    @PutMapping("/disable/{shareLinkId}")
    public ResponseEntity<Boolean> disableShareLink(@PathVariable Long shareLinkId) {
        boolean disabled = shareService.disableShareLink(shareLinkId);
        return ResponseEntity.ok(disabled);
    }
    
    @GetMapping("/album/{albumId}")
    public ResponseEntity<List<ShareLink>> getShareLinksByAlbum(@PathVariable Long albumId) {
        Album album = albumService.getAlbumById(albumId);
        if (album == null) {
            return ResponseEntity.notFound().build();
        }
        
        List<ShareLink> shareLinks = shareService.getShareLinksByAlbum(album);
        return ResponseEntity.ok(shareLinks);
    }
    
    @GetMapping("/me")
    public ResponseEntity<List<ShareLink>> getMyShareLinks() {
        User currentUser = getCurrentUser();
        List<ShareLink> shareLinks = shareService.getShareLinksByUser(currentUser);
        return ResponseEntity.ok(shareLinks);
    }
    
    @PostMapping("/cleanup")
    public ResponseEntity<Integer> cleanupExpiredLinks() {
        int count = shareService.cleanupExpiredLinks();
        return ResponseEntity.ok(count);
    }
}