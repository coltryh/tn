package com.example.smartalbum.controller;

import com.example.smartalbum.entity.Image;
import com.example.smartalbum.entity.User;
import com.example.smartalbum.service.AIService;
import com.example.smartalbum.service.ImageService;
import com.example.smartalbum.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.util.List;

@RestController
@RequestMapping("/api/images")
public class ImageController {

    @Autowired
    private ImageService imageService;

    @Autowired
    private AIService aiService;
    
    @Autowired
    private UserService userService;

    private User getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        return userService.getUserByUsername(userDetails.getUsername());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Image> getImageById(@PathVariable Long id) {
        Image image = imageService.getImageById(id);
        return image != null ? ResponseEntity.ok(image) : ResponseEntity.notFound().build();
    }

    @GetMapping("/album/{albumId}")
    public ResponseEntity<List<Image>> getImagesByAlbumId(@PathVariable Long albumId) {
        List<Image> images = imageService.getImagesByAlbumId(albumId);
        return ResponseEntity.ok(images);
    }

    @GetMapping("/me")
    public ResponseEntity<List<Image>> getMyImages() {
        User currentUser = getCurrentUser();
        List<Image> images = imageService.getImagesByUserId(currentUser.getId());
        return ResponseEntity.ok(images);
    }

    @PostMapping("/upload")
    public ResponseEntity<?> uploadImage(@RequestParam("file") MultipartFile file,
                                        @RequestParam(value = "albumId", required = false) Long albumId) {
        User currentUser = getCurrentUser();
        Image uploadedImage = imageService.uploadImage(file, albumId, currentUser);
        return uploadedImage != null ? ResponseEntity.status(HttpStatus.CREATED).body(uploadedImage) : ResponseEntity.badRequest().body("图片上传失败");
    }
    
    @PostMapping("/batch-upload")
    public ResponseEntity<?> batchUploadImages(@RequestParam("files") List<MultipartFile> files,
                                             @RequestParam(value = "albumId", required = false) Long albumId) {
        User currentUser = getCurrentUser();
        List<Image> uploadedImages = imageService.batchUploadImages(files, albumId, currentUser);
        return uploadedImages.isEmpty() ? ResponseEntity.badRequest().body("图片上传失败") : ResponseEntity.status(HttpStatus.CREATED).body(uploadedImages);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Image> updateImage(@PathVariable Long id, @RequestBody Image image) {
        image.setId(id);
        boolean success = imageService.updateImage(image);
        return success ? ResponseEntity.ok(image) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteImage(@PathVariable Long id) {
        boolean success = imageService.deleteImage(id);
        return success ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    @PostMapping("/batch-delete")
    public ResponseEntity<Void> batchDeleteImages(@RequestBody List<Long> ids) {
        boolean success = imageService.batchDeleteImages(ids);
        return success ? ResponseEntity.noContent().build() : ResponseEntity.badRequest().build();
    }
    
    @GetMapping("/search/tag/{tagName}")
    public ResponseEntity<List<Image>> searchImagesByTag(@PathVariable String tagName) {
        User currentUser = getCurrentUser();
        List<Image> images = imageService.searchImagesByTag(tagName, currentUser);
        return ResponseEntity.ok(images);
    }
    
    @GetMapping("/search/location/{location}")
    public ResponseEntity<List<Image>> searchImagesByLocation(@PathVariable String location) {
        User currentUser = getCurrentUser();
        List<Image> images = imageService.searchImagesByLocation(location, currentUser);
        return ResponseEntity.ok(images);
    }
    
    @GetMapping("/search/advanced")
    public ResponseEntity<List<Image>> advancedSearch(
            @RequestParam(required = false) String tagName,
            @RequestParam(required = false) String location,
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String endDate,
            @RequestParam(required = false) String keyword) {
        
        User currentUser = getCurrentUser();
        
        // 处理日期参数
        java.util.Date start = null;
        java.util.Date end = null;
        try {
            if (startDate != null && !startDate.isEmpty()) {
                start = new java.text.SimpleDateFormat("yyyy-MM-dd").parse(startDate);
            }
            if (endDate != null && !endDate.isEmpty()) {
                // 结束日期设置为当天的最后一秒
                java.util.Date tempEnd = new java.text.SimpleDateFormat("yyyy-MM-dd").parse(endDate);
                end = new java.util.Date(tempEnd.getTime() + 24 * 60 * 60 * 1000 - 1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        List<Image> images = imageService.advancedSearch(currentUser, tagName, location, start, end, keyword);
        return ResponseEntity.ok(images);
    }
}