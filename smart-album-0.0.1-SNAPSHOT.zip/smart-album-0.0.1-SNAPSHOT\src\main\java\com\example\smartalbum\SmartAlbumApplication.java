package com.example.smartalbum;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.mybatis.spring.annotation.MapperScan;

@SpringBootApplication
@MapperScan("com.example.smartalbum.mapper")
public class SmartAlbumApplication {

    public static void main(String[] args) {
        SpringApplication.run(SmartAlbumApplication.class, args);
    }

}