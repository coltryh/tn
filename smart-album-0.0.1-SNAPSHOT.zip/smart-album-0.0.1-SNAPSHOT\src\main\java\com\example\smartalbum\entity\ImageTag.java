package com.example.smartalbum.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;

@Data
@Entity
@Table(name = "image_tag")
@TableIndex(name = "idx_image_tag", columnList = "image_id, tag_name", unique = true)
public class ImageTag {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "image_id", nullable = false)
    private Image image;

    @Column(name = "tag_name", nullable = false, length = 50)
    private String tagName;

    @Column(name = "confidence", nullable = false)
    private Double confidence = 1.0;

    @Column(name = "created_at", nullable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @Column(name = "tag_type", nullable = false, length = 20)
    private String tagType = "ai_generated";

    @PrePersist
    protected void onCreate() {
        createdAt = new Date();
    }
}