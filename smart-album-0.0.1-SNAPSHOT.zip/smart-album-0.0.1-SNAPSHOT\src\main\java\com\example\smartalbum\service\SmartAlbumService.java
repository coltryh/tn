package com.example.smartalbum.service;

import com.example.smartalbum.entity.Album;
import com.example.smartalbum.entity.Image;
import com.example.smartalbum.entity.ImageTag;
import com.example.smartalbum.entity.User;
import java.util.List;

public interface SmartAlbumService {
    /**
     * 自动为图片生成标签
     * @param image 图片实体
     * @return 生成的标签列表
     */
    List<ImageTag> autoGenerateTags(Image image);
    
    /**
     * 为图片添加标签
     * @param image 图片实体
     * @param tagName 标签名称
     * @param confidence 置信度
     * @param tagType 标签类型
     */
    ImageTag addTagToImage(Image image, String tagName, Double confidence, String tagType);
    
    /**
     * 从图片中移除标签
     * @param image 图片实体
     * @param tagName 标签名称
     */
    boolean removeTagFromImage(Image image, String tagName);
    
    /**
     * 根据标签自动创建或更新智能分类相册
     * @param user 用户
     * @param tagName 标签名称
     * @param tagType 标签类型
     * @return 创建或更新的相册
     */
    Album autoCreateSmartAlbum(User user, String tagName, String tagType);
    
    /**
     * 将图片添加到相应的智能分类相册
     * @param image 图片
     */
    void addImageToSmartAlbums(Image image);
    
    /**
     * 获取用户的所有智能分类相册
     * @param user 用户
     * @return 智能分类相册列表
     */
    List<Album> getSmartAlbumsByUser(User user);
    
    /**
     * 更新智能相册的封面图片
     * @param album 相册
     * @param image 图片
     */
    void updateSmartAlbumCover(Album album, Image image);
}