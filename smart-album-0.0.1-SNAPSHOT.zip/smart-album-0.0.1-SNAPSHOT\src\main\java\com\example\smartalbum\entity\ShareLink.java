package com.example.smartalbum.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;

@Data
@Entity
@Table(name = "share_link")
public class ShareLink {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "album_id", nullable = false)
    private Album album;
    
    @Column(name = "share_token", nullable = false, unique = true, length = 100)
    private String shareToken;
    
    @Column(name = "expire_time")
    @Temporal(TemporalType.TIMESTAMP)
    private Date expireTime;
    
    @Column(name = "access_password", length = 50)
    private String accessPassword;
    
    @Column(name = "permission", nullable = false, length = 20)
    private String permission = "view";
    
    @Column(name = "created_at", nullable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by", nullable = false)
    private User createdBy;
    
    @Column(name = "is_active", nullable = false)
    private Boolean isActive = true;
    
    @Column(name = "view_count", nullable = false)
    private Integer viewCount = 0;
    
    @PrePersist
    protected void onCreate() {
        createdAt = new Date();
    }
}