package com.example.smartalbum.service;

import com.example.smartalbum.entity.Image;
import com.example.smartalbum.entity.User;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;
import java.util.List;

public interface ImageService {
    Image getImageById(Long id);
    List<Image> getImagesByAlbumId(Long albumId);
    List<Image> getImagesByUserId(Long userId);
    Image uploadImage(MultipartFile file, Long albumId, User user);
    List<Image> batchUploadImages(List<MultipartFile> files, Long albumId, User user);
    boolean updateImage(Image image);
    boolean deleteImage(Long id);
    boolean batchDeleteImages(List<Long> ids);
    List<Image> searchImagesByTag(String tagName, User user);
    List<Image> searchImagesByLocation(String location, User user);
    List<Image> searchImagesByTimeRange(User user, Date startDate, Date endDate);
    
    // 高级搜索 - 支持多条件组合
    List<Image> advancedSearch(User user, String tagName, String location, Date startDate, Date endDate, String keyword);
}