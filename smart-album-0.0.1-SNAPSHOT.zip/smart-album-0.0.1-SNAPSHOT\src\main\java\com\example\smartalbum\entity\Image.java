package com.example.smartalbum.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
@Entity
@Table(name = "image")
public class Image {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 200)
    private String name;

    @Column(nullable = false, length = 500)
    private String path;

    @Column(nullable = false, length = 500)
    private String url;

    @Column(nullable = false)
    private Long size;

    @Column(nullable = false)
    private Integer width;

    @Column(nullable = false)
    private Integer height;

    @Column(nullable = false, length = 20)
    private String format;

    @Column(name = "upload_time", nullable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date uploadTime;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "album_id")
    private Album album;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "ocr_processed", nullable = false)
    private Boolean ocrProcessed = false;

    @Column(name = "ai_tagged", nullable = false)
    private Boolean aiTagged = false;

    @Column(name = "face_detected", nullable = false)
    private Boolean faceDetected = false;

    @Column(name = "thumbnail_url", length = 500)
    private String thumbnailUrl;

    @Column(name = "compressed", nullable = false)
    private Boolean compressed = false;

    @Column(name = "location", length = 100)
    private String location;

    @Column(name = "shooting_time")
    @Temporal(TemporalType.TIMESTAMP)
    private Date shootingTime;

    @OneToMany(mappedBy = "image", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<ImageTag> tags;

    @OneToMany(mappedBy = "image", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<OcrResult> ocrResults;

    @OneToMany(mappedBy = "image", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<FaceInfo> faceInfos;

    @OneToMany(mappedBy = "image", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<ResumeInfo> resumeInfos;

    @PrePersist
    protected void onCreate() {
        uploadTime = new Date();
    }
}