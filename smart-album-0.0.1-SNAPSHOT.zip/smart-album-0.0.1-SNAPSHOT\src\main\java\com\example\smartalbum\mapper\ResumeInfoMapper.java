package com.example.smartalbum.mapper;

import com.example.smartalbum.entity.ResumeInfo;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ResumeInfoMapper {
    ResumeInfo selectById(Long id);
    ResumeInfo selectByImageId(Long imageId);
    int insert(ResumeInfo resumeInfo);
    int update(ResumeInfo resumeInfo);
    int delete(Long id);
}