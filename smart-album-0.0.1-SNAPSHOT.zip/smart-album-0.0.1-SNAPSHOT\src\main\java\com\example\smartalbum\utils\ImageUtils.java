package com.example.smartalbum.utils;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.UUID;

public class ImageUtils {
    
    /**
     * 生成缩略图
     * @param imagePath 原图路径
     * @param thumbnailPath 缩略图保存路径
     * @param width 缩略图宽度
     * @param height 缩略图高度
     * @return 缩略图文件名
     * @throws IOException 图片处理异常
     */
    public static String generateThumbnail(String imagePath, String thumbnailPath, int width, int height) throws IOException {
        // 创建缩略图目录
        File thumbnailDir = new File(thumbnailPath);
        if (!thumbnailDir.exists()) {
            thumbnailDir.mkdirs();
        }
        
        // 读取原图
        File originalFile = new File(imagePath);
        BufferedImage originalImage = ImageIO.read(originalFile);
        
        // 计算缩放比例
        double scale = Math.min((double) width / originalImage.getWidth(), (double) height / originalImage.getHeight());
        int newWidth = (int) (originalImage.getWidth() * scale);
        int newHeight = (int) (originalImage.getHeight() * scale);
        
        // 创建缩略图
        BufferedImage thumbnail = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = thumbnail.createGraphics();
        g2d.drawImage(originalImage, 0, 0, newWidth, newHeight, null);
        g2d.dispose();
        
        // 保存缩略图
        String fileExtension = imagePath.substring(imagePath.lastIndexOf(".") + 1);
        String thumbnailFileName = UUID.randomUUID().toString() + "." + fileExtension;
        String thumbnailFilePath = thumbnailPath + File.separator + thumbnailFileName;
        
        File thumbnailFile = new File(thumbnailFilePath);
        ImageIO.write(thumbnail, fileExtension, thumbnailFile);
        
        return thumbnailFileName;
    }
    
    /**
     * 压缩图片
     * @param imagePath 原图路径
     * @param compressedPath 压缩后图片保存路径
     * @param maxWidth 最大宽度
     * @param maxHeight 最大高度
     * @param quality 压缩质量 (0.0 - 1.0)
     * @return 压缩后图片文件名
     * @throws IOException 图片处理异常
     */
    public static String compressImage(String imagePath, String compressedPath, int maxWidth, int maxHeight, float quality) throws IOException {
        // 创建压缩图片目录
        File compressedDir = new File(compressedPath);
        if (!compressedDir.exists()) {
            compressedDir.mkdirs();
        }
        
        // 读取原图
        File originalFile = new File(imagePath);
        BufferedImage originalImage = ImageIO.read(originalFile);
        
        // 计算缩放比例
        double scale = Math.min((double) maxWidth / originalImage.getWidth(), (double) maxHeight / originalImage.getHeight());
        int newWidth = (int) (originalImage.getWidth() * scale);
        int newHeight = (int) (originalImage.getHeight() * scale);
        
        // 创建压缩图片
        BufferedImage compressedImage = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = compressedImage.createGraphics();
        g2d.drawImage(originalImage, 0, 0, newWidth, newHeight, null);
        g2d.dispose();
        
        // 保存压缩图片
        String fileExtension = imagePath.substring(imagePath.lastIndexOf(".") + 1);
        String compressedFileName = UUID.randomUUID().toString() + "." + fileExtension;
        String compressedFilePath = compressedPath + File.separator + compressedFileName;
        
        File compressedFile = new File(compressedFilePath);
        ImageIO.write(compressedImage, fileExtension, compressedFile);
        
        return compressedFileName;
    }
    
    /**
     * 获取图片文件的扩展名
     * @param fileName 文件名
     * @return 文件扩展名
     */
    public static String getFileExtension(String fileName) {
        if (fileName == null || fileName.isEmpty()) {
            return "jpg";
        }
        int dotIndex = fileName.lastIndexOf(".");
        if (dotIndex == -1) {
            return "jpg";
        }
        return fileName.substring(dotIndex + 1).toLowerCase();
    }
    
    /**
     * 检查文件是否为图片
     * @param fileName 文件名
     * @return 是否为图片
     */
    public static boolean isImage(String fileName) {
        String[] imageExtensions = {"jpg", "jpeg", "png", "gif", "bmp", "webp"};
        String extension = getFileExtension(fileName);
        for (String ext : imageExtensions) {
            if (ext.equals(extension)) {
                return true;
            }
        }
        return false;
    }
}