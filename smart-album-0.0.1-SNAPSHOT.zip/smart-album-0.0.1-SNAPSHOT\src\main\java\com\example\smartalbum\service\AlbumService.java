package com.example.smartalbum.service;

import com.example.smartalbum.entity.Album;
import com.example.smartalbum.entity.User;
import java.util.List;

public interface AlbumService {
    Album getAlbumById(Long id);
    List<Album> getAlbumsByUserId(Long userId);
    List<Album> getAlbumsByUser(User user);
    List<Album> getPublicAlbumsByUser(User user);
    Album createAlbum(Album album, User user);
    boolean updateAlbum(Album album);
    boolean deleteAlbum(Long id);
}