package com.example.smartalbum.mapper;

import com.example.smartalbum.entity.OcrResult;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OcrResultMapper {
    OcrResult selectById(Long id);
    OcrResult selectByImageId(Long imageId);
    int insert(OcrResult ocrResult);
    int update(OcrResult ocrResult);
    int delete(Long id);
}