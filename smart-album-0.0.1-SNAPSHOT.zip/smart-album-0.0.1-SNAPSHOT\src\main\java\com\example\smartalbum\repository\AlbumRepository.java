package com.example.smartalbum.repository;

import com.example.smartalbum.entity.Album;
import com.example.smartalbum.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AlbumRepository extends JpaRepository<Album, Long> {
    List<Album> findByUser(User user);
    List<Album> findByUserAndIsPublicTrue(User user);
    boolean existsByNameAndUser(String name, User user);
}