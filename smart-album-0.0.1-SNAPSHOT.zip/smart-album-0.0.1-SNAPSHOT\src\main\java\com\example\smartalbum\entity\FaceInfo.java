package com.example.smartalbum.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;

@Data
@Entity
@Table(name = "face_info")
public class FaceInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "image_id", nullable = false)
    private Image image;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "face_id", length = 100)
    private String faceId;

    @Column(name = "face_group_id")
    private Long faceGroupId;

    @Column(name = "confidence", nullable = false)
    private Double confidence = 0.0;
    
    // 人脸坐标
    @Column(name = "x", nullable = false)
    private Integer x = 0;
    
    @Column(name = "y", nullable = false)
    private Integer y = 0;
    
    @Column(name = "width", nullable = false)
    private Integer width = 0;
    
    @Column(name = "height", nullable = false)
    private Integer height = 0;

    @Column(name = "bounding_box", length = 100)
    private String boundingBox;

    @Column(name = "created_at", nullable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @Column(name = "is_main", nullable = false)
    private Boolean isMain = false;

    @Column(name = "face_thumbnail_url", length = 500)
    private String faceThumbnailUrl;

    @PrePersist
    protected void onCreate() {
        createdAt = new Date();
    }
}