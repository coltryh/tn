package com.example.smartalbum.config;

import org.springframework.amqp.core.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {
    
    // 图片处理队列
    public static final String IMAGE_PROCESSING_QUEUE = "image_processing_queue";
    // AI识别队列
    public static final String AI_RECOGNITION_QUEUE = "ai_recognition_queue";
    // 人脸识别队列
    public static final String FACE_RECOGNITION_QUEUE = "face_recognition_queue";
    // 图片处理交换机
    public static final String IMAGE_EXCHANGE = "image_exchange";
    
    // 创建交换机
    @Bean
    public DirectExchange imageExchange() {
        return new DirectExchange(IMAGE_EXCHANGE);
    }
    
    // 创建图片处理队列
    @Bean
    public Queue imageProcessingQueue() {
        return new Queue(IMAGE_PROCESSING_QUEUE, true);
    }
    
    // 创建AI识别队列
    @Bean
    public Queue aiRecognitionQueue() {
        return new Queue(AI_RECOGNITION_QUEUE, true);
    }
    
    // 创建人脸识别队列
    @Bean
    public Queue faceRecognitionQueue() {
        return new Queue(FACE_RECOGNITION_QUEUE, true);
    }
    
    // 绑定图片处理队列到交换机
    @Bean
    public Binding bindingImageProcessingQueue(DirectExchange imageExchange, Queue imageProcessingQueue) {
        return BindingBuilder.bind(imageProcessingQueue).to(imageExchange).with("image.process");
    }
    
    // 绑定AI识别队列到交换机
    @Bean
    public Binding bindingAiRecognitionQueue(DirectExchange imageExchange, Queue aiRecognitionQueue) {
        return BindingBuilder.bind(aiRecognitionQueue).to(imageExchange).with("ai.recognize");
    }
    
    // 绑定人脸识别队列到交换机
    @Bean
    public Binding bindingFaceRecognitionQueue(DirectExchange imageExchange, Queue faceRecognitionQueue) {
        return BindingBuilder.bind(faceRecognitionQueue).to(imageExchange).with("face.recognize");
    }
}