package com.example.smartalbum.service.impl;

import com.example.smartalbum.entity.Album;
import com.example.smartalbum.entity.ShareLink;
import com.example.smartalbum.entity.User;
import com.example.smartalbum.repository.ShareLinkRepository;
import com.example.smartalbum.service.ShareService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class ShareServiceImpl implements ShareService {

    @Autowired
    private ShareLinkRepository shareLinkRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    @Transactional
    public ShareLink generateShareLink(Album album, User user, Integer expireDays, String password, String permission) {
        ShareLink shareLink = new ShareLink();
        
        // 生成唯一的分享令牌
        String shareToken;
        do {
            shareToken = UUID.randomUUID().toString().replace("-", "");
        } while (shareLinkRepository.existsByShareToken(shareToken));
        
        shareLink.setShareToken(shareToken);
        shareLink.setAlbum(album);
        shareLink.setCreatedBy(user);
        shareLink.setPermission(permission);
        
        // 设置过期时间
        if (expireDays != null && expireDays > 0) {
            Date expireTime = new Date();
            expireTime.setTime(expireTime.getTime() + expireDays * 24 * 60 * 60 * 1000);
            shareLink.setExpireTime(expireTime);
        }
        
        // 设置访问密码
        if (password != null && !password.isEmpty()) {
            shareLink.setAccessPassword(passwordEncoder.encode(password));
        }
        
        return shareLinkRepository.save(shareLink);
    }

    @Override
    public boolean validateShareLink(String shareToken, String password) {
        Optional<ShareLink> optionalShareLink = shareLinkRepository.findByShareToken(shareToken);
        if (optionalShareLink.isEmpty()) {
            return false;
        }
        
        ShareLink shareLink = optionalShareLink.get();
        
        // 检查链接是否被禁用
        if (!shareLink.getIsActive()) {
            return false;
        }
        
        // 检查链接是否过期
        if (shareLink.getExpireTime() != null && shareLink.getExpireTime().before(new Date())) {
            return false;
        }
        
        // 检查访问密码
        if (shareLink.getAccessPassword() != null && !shareLink.getAccessPassword().isEmpty()) {
            if (password == null || password.isEmpty()) {
                return false;
            }
            return passwordEncoder.matches(password, shareLink.getAccessPassword());
        }
        
        return true;
    }

    @Override
    public ShareLink getShareLinkByToken(String shareToken) {
        Optional<ShareLink> optionalShareLink = shareLinkRepository.findByShareToken(shareToken);
        return optionalShareLink.orElse(null);
    }

    @Override
    @Transactional
    public void updateViewCount(ShareLink shareLink) {
        shareLink.setViewCount(shareLink.getViewCount() + 1);
        shareLinkRepository.save(shareLink);
    }

    @Override
    @Transactional
    public boolean disableShareLink(Long shareLinkId) {
        Optional<ShareLink> optionalShareLink = shareLinkRepository.findById(shareLinkId);
        if (optionalShareLink.isPresent()) {
            ShareLink shareLink = optionalShareLink.get();
            shareLink.setIsActive(false);
            shareLinkRepository.save(shareLink);
            return true;
        }
        return false;
    }

    @Override
    public List<ShareLink> getShareLinksByAlbum(Album album) {
        return shareLinkRepository.findByAlbum(album);
    }

    @Override
    public List<ShareLink> getShareLinksByUser(User user) {
        return shareLinkRepository.findByCreatedBy(user);
    }

    @Override
    @Transactional
    public int cleanupExpiredLinks() {
        // 获取过期的链接
        List<ShareLink> expiredLinks = shareLinkRepository.findByExpireTimeBefore(new Date());
        int count = expiredLinks.size();
        
        // 禁用过期链接
        for (ShareLink link : expiredLinks) {
            link.setIsActive(false);
        }
        shareLinkRepository.saveAll(expiredLinks);
        
        return count;
    }
}