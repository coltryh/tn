package com.example.smartalbum.performance;

import com.example.smartalbum.entity.User;
import com.example.smartalbum.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class PerformanceTest {
    
    @Autowired
    private UserService userService;
    
    /**
     * 测试用户查询性能
     */
    @Test
    public void testUserQueryPerformance() {
        long startTime = System.currentTimeMillis();
        
        // 测试1000次用户查询
        for (int i = 0; i < 1000; i++) {
            User user = userService.getUserById(1L);
        }
        
        long endTime = System.currentTimeMillis();
        long duration = endTime - startTime;
        
        System.out.println("1000次用户查询耗时: " + duration + "ms");
        System.out.println("平均每次查询耗时: " + (duration / 1000.0) + "ms");
    }
    
    /**
     * 测试用户注册性能
     */
    @Test
    public void testUserRegistrationPerformance() {
        long startTime = System.currentTimeMillis();
        
        // 测试100次用户注册
        for (int i = 0; i < 100; i++) {
            User user = new User();
            user.setUsername("test_user_" + i);
            user.setPassword("password123");
            user.setEmail("test_" + i + "@example.com");
            userService.createUser(user);
        }
        
        long endTime = System.currentTimeMillis();
        long duration = endTime - startTime;
        
        System.out.println("100次用户注册耗时: " + duration + "ms");
        System.out.println("平均每次注册耗时: " + (duration / 100.0) + "ms");
    }
}