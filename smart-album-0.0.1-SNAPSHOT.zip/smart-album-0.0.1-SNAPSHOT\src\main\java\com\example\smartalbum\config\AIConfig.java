package com.example.smartalbum.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AIConfig {
    
    @Value("${ai.provider:local}")
    private String aiProvider;
    
    // 腾讯云AI配置
    @Value("${ai.tencent.secretId:}")
    private String tencentSecretId;
    
    @Value("${ai.tencent.secretKey:}")
    private String tencentSecretKey;
    
    @Value("${ai.tencent.region:ap-beijing}")
    private String tencentRegion;
    
    // 百度AI配置
    @Value("${ai.baidu.apiKey:}")
    private String baiduApiKey;
    
    @Value("${ai.baidu.secretKey:}")
    private String baiduSecretKey;
    
    // 阿里云AI配置
    @Value("${ai.aliyun.accessKeyId:}")
    private String aliyunAccessKeyId;
    
    @Value("${ai.aliyun.accessKeySecret:}")
    private String aliyunAccessKeySecret;
    
    @Value("${ai.aliyun.regionId:cn-shanghai}")
    private String aliyunRegionId;
    
    // getter方法
    public String getAiProvider() {
        return aiProvider;
    }
    
    public String getTencentSecretId() {
        return tencentSecretId;
    }
    
    public String getTencentSecretKey() {
        return tencentSecretKey;
    }
    
    public String getTencentRegion() {
        return tencentRegion;
    }
    
    public String getBaiduApiKey() {
        return baiduApiKey;
    }
    
    public String getBaiduSecretKey() {
        return baiduSecretKey;
    }
    
    public String getAliyunAccessKeyId() {
        return aliyunAccessKeyId;
    }
    
    public String getAliyunAccessKeySecret() {
        return aliyunAccessKeySecret;
    }
    
    public String getAliyunRegionId() {
        return aliyunRegionId;
    }
}