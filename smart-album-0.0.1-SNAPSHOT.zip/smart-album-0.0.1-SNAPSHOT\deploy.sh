#!/bin/bash

# 智能相册管理系统部署脚本

# 项目名称
PROJECT_NAME="smart-album"
# 版本号
VERSION="0.0.1-SNAPSHOT"
# Docker镜像名称
IMAGE_NAME="$PROJECT_NAME:$VERSION"
# 阿里云Docker仓库地址（根据云部署指南替换）
REGISTRY="crpi-rhj5mdnb8mtfuv16.cn-shanghai.personal.cr.aliyuncs.com"
# Docker仓库命名空间（根据云部署指南替换）
NAMESPACE="definitely_docker"
# 完整镜像名称
FULL_IMAGE_NAME="$REGISTRY/$NAMESPACE/$IMAGE_NAME"

echo "===== 智能相册管理系统部署脚本 ====="

echo "1. 清理并打包项目..."
mvn clean package -DskipTests -Dmaven.wagon.http.ssl.insecure=true -Dmaven.wagon.http.ssl.allowall=true

if [ $? -ne 0 ]; then
    echo "打包失败，请检查项目代码和依赖配置"
    exit 1
fi

echo "2. 构建Docker镜像..."
docker build -t $IMAGE_NAME .

if [ $? -ne 0 ]; then
    echo "Docker镜像构建失败"
    exit 1
fi

echo "3. 登录阿里云Docker仓库..."
docker login --username=阿里云账号 $REGISTRY

if [ $? -ne 0 ]; then
    echo "Docker仓库登录失败，请检查用户名和密码"
    exit 1
fi

echo "4. 标记Docker镜像..."
docker tag $IMAGE_NAME $FULL_IMAGE_NAME

echo "5. 推送Docker镜像到仓库..."
docker push $FULL_IMAGE_NAME

if [ $? -ne 0 ]; then
    echo "Docker镜像推送失败"
    exit 1
fi

echo "6. 部署完成！"
echo "镜像已成功推送至阿里云Docker仓库：$FULL_IMAGE_NAME"
echo "在服务器上运行以下命令启动服务："
echo "docker run -d -p 8080:8080 --name $PROJECT_NAME $FULL_IMAGE_NAME"
echo "服务启动后，可通过 http://服务器IP:8080 访问前端页面"
echo "可通过 http://服务器IP:8080/api/images/ 访问API接口"

echo "===== 部署脚本执行完成 ====="
