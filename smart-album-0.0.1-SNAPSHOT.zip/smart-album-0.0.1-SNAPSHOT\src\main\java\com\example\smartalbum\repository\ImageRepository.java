package com.example.smartalbum.repository;

import com.example.smartalbum.entity.Album;
import com.example.smartalbum.entity.Image;
import com.example.smartalbum.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface ImageRepository extends JpaRepository<Image, Long> {
    List<Image> findByAlbum(Album album);
    List<Image> findByUser(User user);
    List<Image> findByUserAndAlbum(User user, Album album);
    
    @Query("SELECT i FROM Image i JOIN i.tags t WHERE t.tagName = :tagName AND i.user = :user")
    List<Image> findByTagNameAndUser(@Param("tagName") String tagName, @Param("user") User user);
    
    List<Image> findByLocation(String location);
    List<Image> findByUserAndLocation(User user, String location);
    
    // 按时间范围搜索
    List<Image> findByUserAndUploadTimeBetween(User user, Date startDate, Date endDate);
    
    // 高级搜索 - 支持多条件组合
    @Query("SELECT DISTINCT i FROM Image i LEFT JOIN i.tags t WHERE i.user = :user " +
           "AND (:tagName IS NULL OR t.tagName = :tagName) " +
           "AND (:location IS NULL OR i.location = :location) " +
           "AND (:startDate IS NULL OR i.uploadTime >= :startDate) " +
           "AND (:endDate IS NULL OR i.uploadTime <= :endDate) " +
           "AND (:keyword IS NULL OR i.name LIKE %:keyword% OR t.tagName LIKE %:keyword%)")
    List<Image> advancedSearch(@Param("user") User user,
                              @Param("tagName") String tagName,
                              @Param("location") String location,
                              @Param("startDate") Date startDate,
                              @Param("endDate") Date endDate,
                              @Param("keyword") String keyword);
}