package com.example.smartalbum.service.impl;

import com.example.smartalbum.entity.Album;
import com.example.smartalbum.entity.User;
import com.example.smartalbum.repository.AlbumRepository;
import com.example.smartalbum.service.AlbumService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class AlbumServiceImpl implements AlbumService {

    @Autowired
    private AlbumRepository albumRepository;

    @Override
    public Album getAlbumById(Long id) {
        Optional<Album> optionalAlbum = albumRepository.findById(id);
        return optionalAlbum.orElse(null);
    }

    @Override
    public List<Album> getAlbumsByUserId(Long userId) {
        User user = new User();
        user.setId(userId);
        return albumRepository.findByUser(user);
    }
    
    @Override
    public List<Album> getAlbumsByUser(User user) {
        return albumRepository.findByUser(user);
    }
    
    @Override
    public List<Album> getPublicAlbumsByUser(User user) {
        return albumRepository.findByUserAndIsPublicTrue(user);
    }

    @Override
    public Album createAlbum(Album album, User user) {
        album.setUser(user);
        return albumRepository.save(album);
    }

    @Override
    public boolean updateAlbum(Album album) {
        if (albumRepository.existsById(album.getId())) {
            albumRepository.save(album);
            return true;
        }
        return false;
    }

    @Override
    public boolean deleteAlbum(Long id) {
        if (albumRepository.existsById(id)) {
            albumRepository.deleteById(id);
            return true;
        }
        return false;
    }
}