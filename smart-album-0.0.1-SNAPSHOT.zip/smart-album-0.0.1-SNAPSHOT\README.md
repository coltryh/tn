# 智能相册管理系统

## 项目简介

智能相册管理系统是一个集图像存储、AI智能识别、分类管理于一体的现代化相册应用。系统能够自动识别图片内容，提取文字信息，并能从简历图片中提取结构化信息。

## 技术栈

- 后端：Spring Boot 3.2.0 + MyBatis 3.0.3 + Java 21
- 数据库：MySQL 8.0
- OCR：Tess4J 5.13.0
- 前端：HTML/CSS/JavaScript

## 功能特性

- 相册管理：创建、修改、删除相册
- 图片管理：上传、下载、删除、移动图片
- OCR识别：自动识别图片中的文字
- 简历提取：从简历图片中提取结构化信息
- AI标签：自动为图片添加标签

## 项目结构

```
smart-album/
├── src/
│   ├── main/
│   │   ├── java/          # Java源代码
│   │   └── resources/     # 资源文件
│   └── test/             # 测试代码
├── target/               # 编译输出目录
├── lib/                  # 第三方依赖库
├── Dockerfile            # Docker镜像构建配置
├── .dockerignore         # Docker构建忽略文件
├── deploy.sh             # Linux/Mac部署脚本
├── deploy.bat            # Windows部署脚本
├── pom.xml               # Maven依赖配置
└── README.md             # 项目说明文档
```

## 快速开始

### 环境要求

- JDK 21
- MySQL 8.0
- Maven 3.9.0+（可选，用于编译）
- Docker（可选，用于容器化部署）

### 方法1：使用Maven编译和运行

```bash
# 编译项目
mvn clean package -DskipTests

# 运行项目
java -jar target/smart-album-0.0.1-SNAPSHOT.jar
```

### 方法2：使用Docker运行

```bash
# 构建Docker镜像
docker build -t smart-album:0.0.1-SNAPSHOT .

# 运行Docker容器
docker run -d -p 8080:8080 --name smart-album smart-album:0.0.1-SNAPSHOT
```

### 方法3：手动编译和运行

1. 下载所有依赖库到lib目录
2. 编译Java文件：
   ```bash
   javac -d target/classes -cp "src/main/java;lib/*" src/main/java/com/example/smartalbum/*.java src/main/java/com/example/smartalbum/**/*.java
   ```
3. 打包成JAR文件
4. 运行JAR文件

## 数据库配置

1. 启动MySQL服务
2. 创建数据库：
   ```sql
   CREATE DATABASE IF NOT EXISTS smart_album CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```
3. 执行建表脚本：
   ```bash
   mysql -u root -p smart_album < src/main/resources/schema.sql
   ```
4. 修改配置文件：
   ```properties
   # src/main/resources/application.properties
   spring.datasource.url=jdbc:mysql://localhost:3306/smart_album?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=UTC
   spring.datasource.username=root
   spring.datasource.password=root
   ```

## OCR配置

1. 下载Tesseract OCR语言数据文件
2. 将下载的`tessdata`目录放置在指定位置
3. 修改配置文件：
   ```properties
   # src/main/resources/application.properties
   ocr.data.path=D:\\Trae  linsihi\\8\\tessdata
   ```

## 访问地址

- 前端页面：http://localhost:8080
- API接口：http://localhost:8080/api/images/

## API文档

### 相册管理

- `GET /api/albums/{id}` - 获取相册详情
- `GET /api/albums/user/{userId}` - 获取用户的所有相册
- `POST /api/albums` - 创建相册
- `PUT /api/albums/{id}` - 更新相册
- `DELETE /api/albums/{id}` - 删除相册

### 图片管理

- `GET /api/images/{id}` - 获取图片详情
- `GET /api/images/album/{albumId}` - 获取相册中的所有图片
- `GET /api/images/user/{userId}` - 获取用户的所有图片
- `POST /api/images/upload` - 上传图片
- `PUT /api/images/{id}` - 更新图片信息
- `DELETE /api/images/{id}` - 删除图片
- `POST /api/images/batch-delete` - 批量删除图片
- `POST /api/images/{id}/ocr` - 对图片进行OCR识别
- `POST /api/images/{id}/extract-resume` - 从图片中提取简历信息

## 部署说明

### 本地部署

1. 确保Java和MySQL已安装并配置正确
2. 编译项目
3. 运行项目
4. 访问前端页面

### 云部署

1. 使用提供的部署脚本（`deploy.sh`或`deploy.bat`）
2. 按照脚本提示输入相关信息
3. 在云服务器上运行Docker容器
4. 配置域名和SSL证书（可选）

## 注意事项

1. 首次运行需要执行数据库脚本
2. OCR功能需要配置Tesseract语言数据文件
3. 图片上传目录需要有写入权限
4. 建议使用Docker部署，简化环境配置

## 开发说明

### 开发环境

- IDE：IntelliJ IDEA或Eclipse
- JDK：21
- Maven：3.9.0+
- MySQL：8.0

### 项目导入

1. 使用IDE导入Maven项目
2. 配置数据库连接
3. 运行`SmartAlbumApplication.java`

## 常见问题

1. **数据库连接失败**：检查MySQL是否启动，配置文件中的连接信息是否正确
2. **端口被占用**：修改`application.properties`中的`server.port`或Docker映射端口
3. **OCR识别失败**：确保已安装Tesseract并配置了正确的数据路径
4. **图片上传失败**：检查上传目录是否存在且有写入权限

## 许可证

MIT License

## 联系方式

如有问题或建议，欢迎联系项目维护人员。
