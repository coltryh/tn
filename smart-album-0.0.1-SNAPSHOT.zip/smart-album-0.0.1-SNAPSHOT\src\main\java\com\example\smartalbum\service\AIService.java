package com.example.smartalbum.service;

import com.example.smartalbum.entity.Image;
import com.example.smartalbum.entity.ImageTag;
import com.example.smartalbum.entity.FaceInfo;
import java.util.List;
import java.util.Map;

public interface AIService {
    /**
     * 对图片进行OCR识别
     * @param imagePath 图片路径
     * @return 识别出的文本
     */
    String ocrImage(String imagePath);

    /**
     * 从简历文本中提取信息
     * @param resumeText 简历文本
     * @return 提取的简历信息（JSON格式）
     */
    Map<String, Object> extractResumeInfo(String resumeText);
    
    /**
     * 通用图像识别（物体、场景识别）
     * @param imagePath 图片路径
     * @return 识别结果，包含场景、物体等信息
     */
    Map<String, Object> recognizeImage(String imagePath);
    
    /**
     * 图像标签生成
     * @param imagePath 图片路径
     * @return 生成的标签列表
     */
    List<ImageTag> generateImageTags(String imagePath, Image image);
    
    /**
     * 人脸检测
     * @param imagePath 图片路径
     * @return 检测到的人脸信息列表
     */
    List<FaceInfo> detectFaces(String imagePath, Image image);
    
    /**
     * 人脸分组
     * @param faceInfos 人脸信息列表
     * @return 分组后的人脸信息，相同人物的脸被标记为同一组
     */
    List<FaceInfo> groupFaces(List<FaceInfo> faceInfos);
    
    /**
     * 设置AI服务提供商
     * @param provider 服务提供商名称（tencent、baidu、aliyun、local）
     */
    void setAIServiceProvider(String provider);
}