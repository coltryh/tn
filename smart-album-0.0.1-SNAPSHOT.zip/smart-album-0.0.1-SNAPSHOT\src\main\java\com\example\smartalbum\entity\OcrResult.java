package com.example.smartalbum.entity;

import lombok.Data;
import java.util.Date;

@Data
public class OcrResult {
    private Long id;
    private Long imageId;
    private String textContent;
    private Double confidence;
    private Date createdAt;
}