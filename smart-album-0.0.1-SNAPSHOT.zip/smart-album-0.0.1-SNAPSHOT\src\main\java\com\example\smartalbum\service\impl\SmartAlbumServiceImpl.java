package com.example.smartalbum.service.impl;

import com.example.smartalbum.entity.Album;
import com.example.smartalbum.entity.Image;
import com.example.smartalbum.entity.ImageTag;
import com.example.smartalbum.entity.User;
import com.example.smartalbum.repository.AlbumRepository;
import com.example.smartalbum.repository.ImageRepository;
import com.example.smartalbum.repository.ImageTagRepository;
import com.example.smartalbum.service.AIService;
import com.example.smartalbum.service.SmartAlbumService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class SmartAlbumServiceImpl implements SmartAlbumService {

    @Autowired
    private AIService aiService;
    
    @Autowired
    private ImageRepository imageRepository;
    
    @Autowired
    private AlbumRepository albumRepository;
    
    @Autowired
    private ImageTagRepository imageTagRepository;

    @Override
    @Transactional
    public List<ImageTag> autoGenerateTags(Image image) {
        // 使用AI服务生成标签
        List<ImageTag> tags = aiService.generateImageTags(image.getPath(), image);
        
        // 保存标签到数据库
        tags = imageTagRepository.saveAll(tags);
        
        // 更新图片的AI标记状态
        image.setAiTagged(true);
        imageRepository.save(image);
        
        return tags;
    }

    @Override
    @Transactional
    public ImageTag addTagToImage(Image image, String tagName, Double confidence, String tagType) {
        // 检查标签是否已存在
        List<ImageTag> existingTags = imageTagRepository.findByImage(image);
        for (ImageTag tag : existingTags) {
            if (tag.getTagName().equals(tagName)) {
                return tag; // 标签已存在，直接返回
            }
        }
        
        // 创建新标签
        ImageTag tag = new ImageTag();
        tag.setImage(image);
        tag.setTagName(tagName);
        tag.setConfidence(confidence != null ? confidence : 1.0);
        tag.setTagType(tagType != null ? tagType : "user");
        tag.setCreatedAt(new Date());
        
        return imageTagRepository.save(tag);
    }

    @Override
    @Transactional
    public boolean removeTagFromImage(Image image, String tagName) {
        List<ImageTag> tags = imageTagRepository.findByImage(image);
        for (ImageTag tag : tags) {
            if (tag.getTagName().equals(tagName)) {
                imageTagRepository.delete(tag);
                return true;
            }
        }
        return false;
    }

    @Override
    @Transactional
    public Album autoCreateSmartAlbum(User user, String tagName, String tagType) {
        // 检查智能相册是否已存在
        String albumName = generateSmartAlbumName(tagName, tagType);
        List<Album> userAlbums = albumRepository.findByUser(user);
        
        for (Album album : userAlbums) {
            if (album.getName().equals(albumName)) {
                return album; // 相册已存在，直接返回
            }
        }
        
        // 创建新的智能相册
        Album smartAlbum = new Album();
        smartAlbum.setName(albumName);
        smartAlbum.setDescription(generateSmartAlbumDescription(tagName, tagType));
        smartAlbum.setUser(user);
        smartAlbum.setIsPublic(false); // 智能相册默认为私有
        
        return albumRepository.save(smartAlbum);
    }

    @Override
    @Transactional
    public void addImageToSmartAlbums(Image image) {
        // 自动生成标签
        List<ImageTag> tags = autoGenerateTags(image);
        
        // 为每个标签创建或更新智能相册
        for (ImageTag tag : tags) {
            Album smartAlbum = autoCreateSmartAlbum(image.getUser(), tag.getTagName(), tag.getTagType());
            
            // 将图片添加到相册
            // 注意：这里需要考虑图片与相册的关联关系，可能需要额外的处理
            // 由于Image实体已经有Album关联，我们需要决定是否直接设置或使用中间表
            // 这里简化处理，直接将图片添加到智能相册
            image.setAlbum(smartAlbum);
            imageRepository.save(image);
            
            // 更新智能相册封面（如果相册还没有封面）
            if (smartAlbum.getCoverImageUrl() == null || smartAlbum.getCoverImageUrl().isEmpty()) {
                updateSmartAlbumCover(smartAlbum, image);
            }
        }
    }

    @Override
    public List<Album> getSmartAlbumsByUser(User user) {
        List<Album> allAlbums = albumRepository.findByUser(user);
        List<Album> smartAlbums = new ArrayList<>();
        
        // 筛选智能相册（这里简单通过名称判断，实际项目中可能需要更复杂的逻辑）
        for (Album album : allAlbums) {
            if (album.getName().startsWith("智能相册 - ")) {
                smartAlbums.add(album);
            }
        }
        
        return smartAlbums;
    }

    @Override
    @Transactional
    public void updateSmartAlbumCover(Album album, Image image) {
        album.setCoverImageUrl(image.getUrl());
        albumRepository.save(album);
    }
    
    /**
     * 生成智能相册名称
     */
    private String generateSmartAlbumName(String tagName, String tagType) {
        return "智能相册 - " + tagName;
    }
    
    /**
     * 生成智能相册描述
     */
    private String generateSmartAlbumDescription(String tagName, String tagType) {
        return "根据\"" + tagName + "\"标签自动生成的智能分类相册";
    }
}