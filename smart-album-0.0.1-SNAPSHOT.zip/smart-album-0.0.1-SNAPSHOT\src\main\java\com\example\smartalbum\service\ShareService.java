package com.example.smartalbum.service;

import com.example.smartalbum.entity.Album;
import com.example.smartalbum.entity.ShareLink;
import com.example.smartalbum.entity.User;

import java.util.Date;
import java.util.List;

public interface ShareService {
    /**
     * 生成相册分享链接
     * @param album 相册
     * @param user 创建分享的用户
     * @param expireDays 过期天数，null表示永不过期
     * @param password 访问密码，null表示不需要密码
     * @param permission 权限：view(查看)或download(下载)
     * @return 分享链接信息
     */
    ShareLink generateShareLink(Album album, User user, Integer expireDays, String password, String permission);
    
    /**
     * 验证分享链接
     * @param shareToken 分享令牌
     * @param password 访问密码，无密码时为null
     * @return 验证结果，true表示验证通过
     */
    boolean validateShareLink(String shareToken, String password);
    
    /**
     * 通过分享令牌获取分享链接
     * @param shareToken 分享令牌
     * @return 分享链接信息
     */
    ShareLink getShareLinkByToken(String shareToken);
    
    /**
     * 更新分享链接访问次数
     * @param shareLink 分享链接
     */
    void updateViewCount(ShareLink shareLink);
    
    /**
     * 禁用分享链接
     * @param shareLinkId 分享链接ID
     * @return 禁用是否成功
     */
    boolean disableShareLink(Long shareLinkId);
    
    /**
     * 获取相册的所有分享链接
     * @param album 相册
     * @return 分享链接列表
     */
    List<ShareLink> getShareLinksByAlbum(Album album);
    
    /**
     * 获取用户创建的所有分享链接
     * @param user 用户
     * @return 分享链接列表
     */
    List<ShareLink> getShareLinksByUser(User user);
    
    /**
     * 清理过期的分享链接
     * @return 清理的链接数量
     */
    int cleanupExpiredLinks();
}