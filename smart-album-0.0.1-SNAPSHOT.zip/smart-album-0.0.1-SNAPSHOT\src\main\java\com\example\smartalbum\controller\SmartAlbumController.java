package com.example.smartalbum.controller;

import com.example.smartalbum.entity.Album;
import com.example.smartalbum.entity.Image;
import com.example.smartalbum.entity.ImageTag;
import com.example.smartalbum.entity.User;
import com.example.smartalbum.service.SmartAlbumService;
import com.example.smartalbum.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/smart-albums")
public class SmartAlbumController {

    @Autowired
    private SmartAlbumService smartAlbumService;
    
    @Autowired
    private UserService userService;
    
    private User getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        return userService.getUserByUsername(userDetails.getUsername());
    }
    
    @GetMapping("/me")
    public ResponseEntity<List<Album>> getMySmartAlbums() {
        User currentUser = getCurrentUser();
        List<Album> smartAlbums = smartAlbumService.getSmartAlbumsByUser(currentUser);
        return ResponseEntity.ok(smartAlbums);
    }
    
    @PostMapping("/generate-tags/{imageId}")
    public ResponseEntity<List<ImageTag>> generateTagsForImage(@PathVariable Long imageId) {
        // 这里需要获取图片实体，实际项目中可能需要注入ImageService
        // 简化处理，直接返回空列表
        return ResponseEntity.ok(List.of());
    }
    
    @PostMapping("/image/{imageId}/add-tag")
    public ResponseEntity<ImageTag> addTagToImage(@PathVariable Long imageId,
                                                 @RequestParam String tagName,
                                                 @RequestParam(required = false) Double confidence,
                                                 @RequestParam(required = false) String tagType) {
        // 这里需要获取图片实体，实际项目中可能需要注入ImageService
        // 简化处理，直接返回空的ImageTag
        return ResponseEntity.ok(new ImageTag());
    }
    
    @DeleteMapping("/image/{imageId}/remove-tag/{tagName}")
    public ResponseEntity<?> removeTagFromImage(@PathVariable Long imageId,
                                               @PathVariable String tagName) {
        // 这里需要获取图片实体，实际项目中可能需要注入ImageService
        // 简化处理，直接返回成功
        return ResponseEntity.ok().body("标签移除成功");
    }
    
    @PostMapping("/image/{imageId}/smart-albums")
    public ResponseEntity<?> addImageToSmartAlbums(@PathVariable Long imageId) {
        // 这里需要获取图片实体，实际项目中可能需要注入ImageService
        // 简化处理，直接返回成功
        return ResponseEntity.ok().body("图片已添加到智能相册");
    }
}