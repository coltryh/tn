package com.example.smartalbum.service.impl;

import com.example.smartalbum.entity.Album;
import com.example.smartalbum.entity.Image;
import com.example.smartalbum.entity.User;
import com.example.smartalbum.repository.AlbumRepository;
import com.example.smartalbum.repository.ImageRepository;
import com.example.smartalbum.service.FaceService;
import com.example.smartalbum.service.ImageService;
import com.example.smartalbum.service.SmartAlbumService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class ImageServiceImpl implements ImageService {

    @Autowired
    private ImageRepository imageRepository;
    
    @Autowired
    private AlbumRepository albumRepository;
    
    @Autowired
    private SmartAlbumService smartAlbumService;
    
    @Autowired
    private FaceService faceService;
    
    @Autowired
    private MessagePublisher messagePublisher;

    private static final String UPLOAD_DIR = "uploads/";

    @Override
    public Image getImageById(Long id) {
        Optional<Image> optionalImage = imageRepository.findById(id);
        return optionalImage.orElse(null);
    }

    @Override
    public List<Image> getImagesByAlbumId(Long albumId) {
        Optional<Album> optionalAlbum = albumRepository.findById(albumId);
        if (optionalAlbum.isPresent()) {
            return imageRepository.findByAlbum(optionalAlbum.get());
        }
        return new ArrayList<>();
    }

    @Override
    public List<Image> getImagesByUserId(Long userId) {
        User user = new User();
        user.setId(userId);
        return imageRepository.findByUser(user);
    }

    @Override
    public Image uploadImage(MultipartFile file, Long albumId, User user) {
        try {
            // 创建上传目录
            File uploadDir = new File(UPLOAD_DIR);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }

            // 生成唯一文件名
            String originalFilename = file.getOriginalFilename();
            String fileExtension = originalFilename.substring(originalFilename.lastIndexOf(".") + 1);
            String fileName = UUID.randomUUID().toString() + "." + fileExtension;
            String filePath = UPLOAD_DIR + fileName;

            // 保存文件
            File dest = new File(filePath);
            file.transferTo(dest);

            // 获取图片信息
            BufferedImage image = ImageIO.read(dest);
            int width = image.getWidth();
            int height = image.getHeight();

            // 保存到数据库
            Image imageEntity = new Image();
            imageEntity.setName(originalFilename);
            imageEntity.setPath(filePath);
            imageEntity.setUrl("/" + filePath);
            imageEntity.setSize(file.getSize());
            imageEntity.setWidth(width);
            imageEntity.setHeight(height);
            imageEntity.setFormat(fileExtension);
            
            if (albumId != null) {
                Optional<Album> optionalAlbum = albumRepository.findById(albumId);
                optionalAlbum.ifPresent(imageEntity::setAlbum);
            }
            
            imageEntity.setUser(user);
            imageEntity.setOcrProcessed(false);
            imageEntity.setAiTagged(false);
            imageEntity.setFaceDetected(false);

            // 保存图片到数据库
            Image savedImage = imageRepository.save(imageEntity);
            
            // 发送图片处理消息到RabbitMQ队列
            messagePublisher.sendImageProcessingMessage(savedImage.getId());
            
            // 发送AI识别消息到RabbitMQ队列
            messagePublisher.sendAiRecognitionMessage(savedImage.getId());
            
            // 发送人脸识别消息到RabbitMQ队列
            messagePublisher.sendFaceRecognitionMessage(savedImage.getId());
            
            return savedImage;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Image> batchUploadImages(List<MultipartFile> files, Long albumId, User user) {
        List<Image> uploadedImages = new ArrayList<>();
        
        for (MultipartFile file : files) {
            Image uploadedImage = uploadImage(file, albumId, user);
            if (uploadedImage != null) {
                uploadedImages.add(uploadedImage);
            }
        }
        
        return uploadedImages;
    }

    @Override
    public boolean updateImage(Image image) {
        if (imageRepository.existsById(image.getId())) {
            imageRepository.save(image);
            return true;
        }
        return false;
    }

    @Override
    public boolean deleteImage(Long id) {
        Optional<Image> optionalImage = imageRepository.findById(id);
        if (optionalImage.isPresent()) {
            Image image = optionalImage.get();
            // 删除文件
            File file = new File(image.getPath());
            if (file.exists()) {
                file.delete();
            }
            // 删除数据库记录
            imageRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public boolean batchDeleteImages(List<Long> ids) {
        for (Long id : ids) {
            deleteImage(id);
        }
        return true;
    }

    @Override
    public List<Image> searchImagesByTag(String tagName, User user) {
        return imageRepository.findByTagNameAndUser(tagName, user);
    }

    @Override
    public List<Image> searchImagesByLocation(String location, User user) {
        return imageRepository.findByUserAndLocation(user, location);
    }
    
    @Override
    public List<Image> searchImagesByTimeRange(User user, Date startDate, Date endDate) {
        return imageRepository.findByUserAndUploadTimeBetween(user, startDate, endDate);
    }
    
    @Override
    public List<Image> advancedSearch(User user, String tagName, String location, Date startDate, Date endDate, String keyword) {
        return imageRepository.advancedSearch(user, tagName, location, startDate, endDate, keyword);
    }
}