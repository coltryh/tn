package com.example.smartalbum.service;

import com.example.smartalbum.entity.User;

public interface UserService {
    User getUserById(Long id);
    User getUserByUsername(String username);
    User getUserByEmail(String email);
    boolean createUser(User user);
    boolean updateUser(User user);
    boolean deleteUser(Long id);
}