package com.example.smartalbum.repository;

import com.example.smartalbum.entity.Image;
import com.example.smartalbum.entity.ImageTag;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ImageTagRepository extends JpaRepository<ImageTag, Long> {
    List<ImageTag> findByImage(Image image);
    List<ImageTag> findByTagName(String tagName);
    List<ImageTag> findByTagType(String tagType);
    void deleteByImage(Image image);
}