package com.example.smartalbum.mapper;

import com.example.smartalbum.entity.Image;
import org.apache.ibatis.annotations.Mapper;
import java.util.List;

@Mapper
public interface ImageMapper {
    Image selectById(Long id);
    List<Image> selectByAlbumId(Long albumId);
    List<Image> selectByUserId(Long userId);
    int insert(Image image);
    int update(Image image);
    int delete(Long id);
    int batchDelete(List<Long> ids);
}