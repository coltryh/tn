package com.example.smartalbum.service.impl;

import com.example.smartalbum.entity.FaceInfo;
import com.example.smartalbum.entity.Image;
import com.example.smartalbum.entity.User;
import com.example.smartalbum.repository.FaceInfoRepository;
import com.example.smartalbum.service.AIService;
import com.example.smartalbum.service.FaceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class FaceServiceImpl implements FaceService {

    @Autowired
    private FaceInfoRepository faceInfoRepository;
    
    @Autowired
    private AIService aiService;

    @Override
    @Transactional
    public List<FaceInfo> detectFaces(Image image) {
        // 使用AI服务检测人脸
        List<FaceInfo> faceInfos = aiService.detectFaces(image.getPath(), image);
        
        // 保存人脸信息到数据库
        faceInfos = faceInfoRepository.saveAll(faceInfos);
        
        // 更新图片的人脸检测状态
        image.setFaceDetected(true);
        
        return faceInfos;
    }

    @Override
    @Transactional
    public FaceInfo recognizeAndGroupFace(FaceInfo faceInfo) {
        // 简单的分组逻辑：查找相似的人脸，如果找到则加入同一组，否则创建新组
        List<FaceInfo> similarFaces = faceInfoRepository.findByUser(faceInfo.getUser());
        
        // 如果没有其他人脸，创建新组
        if (similarFaces.isEmpty()) {
            faceInfo.setFaceGroupId(1L);
        } else {
            // 简单的分组策略：将所有脸分到同一组，实际项目中应使用更复杂的人脸识别算法
            // 这里我们使用模拟的分组逻辑
            Long groupId = similarFaces.get(0).getFaceGroupId() != null ? similarFaces.get(0).getFaceGroupId() : 1L;
            faceInfo.setFaceGroupId(groupId);
        }
        
        // 生成唯一的人脸ID
        if (faceInfo.getFaceId() == null || faceInfo.getFaceId().isEmpty()) {
            faceInfo.setFaceId(UUID.randomUUID().toString());
        }
        
        return faceInfoRepository.save(faceInfo);
    }

    @Override
    @Transactional
    public List<FaceInfo> groupFacesInImage(Image image) {
        // 检测图片中的人脸
        List<FaceInfo> faceInfos = detectFaces(image);
        
        // 对每个人脸进行分组
        for (FaceInfo faceInfo : faceInfos) {
            recognizeAndGroupFace(faceInfo);
        }
        
        return faceInfos;
    }

    @Override
    public List<Long> getUserFaceGroups(User user) {
        // 获取用户的所有人脸分组ID，去重
        List<FaceInfo> allFaces = faceInfoRepository.findByUser(user);
        List<Long> groupIds = new ArrayList<>();
        
        for (FaceInfo face : allFaces) {
            if (face.getFaceGroupId() != null && !groupIds.contains(face.getFaceGroupId())) {
                groupIds.add(face.getFaceGroupId());
            }
        }
        
        return groupIds;
    }

    @Override
    public List<FaceInfo> getFacesByGroup(User user, Long faceGroupId) {
        return faceInfoRepository.findByUserAndFaceGroupId(user, faceGroupId);
    }

    @Override
    @Transactional
    public FaceInfo updateFaceGroup(FaceInfo faceInfo, Long newGroupId) {
        faceInfo.setFaceGroupId(newGroupId);
        return faceInfoRepository.save(faceInfo);
    }

    @Override
    @Transactional
    public FaceInfo setAsMainFace(FaceInfo faceInfo) {
        // 将该分组中的所有其他脸设置为非主要脸
        List<FaceInfo> groupFaces = faceInfoRepository.findByUserAndFaceGroupId(faceInfo.getUser(), faceInfo.getFaceGroupId());
        for (FaceInfo face : groupFaces) {
            face.setIsMain(false);
        }
        
        // 将当前脸设置为主要脸
        faceInfo.setIsMain(true);
        
        faceInfoRepository.saveAll(groupFaces);
        return faceInfoRepository.save(faceInfo);
    }
}