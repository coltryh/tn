package com.example.smartalbum.repository;

import com.example.smartalbum.entity.FaceInfo;
import com.example.smartalbum.entity.Image;
import com.example.smartalbum.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FaceInfoRepository extends JpaRepository<FaceInfo, Long> {
    List<FaceInfo> findByImage(Image image);
    List<FaceInfo> findByUser(User user);
    List<FaceInfo> findByFaceGroupId(Long faceGroupId);
    List<FaceInfo> findByUserAndFaceGroupId(User user, Long faceGroupId);
}