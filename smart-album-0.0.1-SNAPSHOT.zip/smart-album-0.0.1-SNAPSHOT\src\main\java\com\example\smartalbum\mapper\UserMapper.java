package com.example.smartalbum.mapper;

import com.example.smartalbum.entity.User;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper {
    User selectById(Long id);
    User selectByUsername(String username);
    User selectByEmail(String email);
    int insert(User user);
    int update(User user);
    int delete(Long id);
}