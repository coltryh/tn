package com.example.smartalbum.service;

import com.example.smartalbum.entity.FaceInfo;
import com.example.smartalbum.entity.Image;
import com.example.smartalbum.entity.User;
import java.util.List;

public interface FaceService {
    /**
     * 检测图片中的人脸
     * @param image 图片实体
     * @return 检测到的人脸信息列表
     */
    List<FaceInfo> detectFaces(Image image);
    
    /**
     * 识别人脸并分组
     * @param faceInfo 人脸信息
     * @return 分组后的人脸信息
     */
    FaceInfo recognizeAndGroupFace(FaceInfo faceInfo);
    
    /**
     * 对图片中的所有人脸进行分组
     * @param image 图片实体
     * @return 分组后的人脸信息列表
     */
    List<FaceInfo> groupFacesInImage(Image image);
    
    /**
     * 获取用户的所有人脸分组
     * @param user 用户
     * @return 人脸分组列表
     */
    List<Long> getUserFaceGroups(User user);
    
    /**
     * 获取分组中的所有人脸
     * @param user 用户
     * @param faceGroupId 人脸分组ID
     * @return 该分组下的所有人脸信息
     */
    List<FaceInfo> getFacesByGroup(User user, Long faceGroupId);
    
    /**
     * 更新人脸分组
     * @param faceInfo 人脸信息
     * @param newGroupId 新的分组ID
     * @return 更新后的人脸信息
     */
    FaceInfo updateFaceGroup(FaceInfo faceInfo, Long newGroupId);
    
    /**
     * 设置人脸为分组的主要人脸
     * @param faceInfo 人脸信息
     * @return 更新后的人脸信息
     */
    FaceInfo setAsMainFace(FaceInfo faceInfo);
}