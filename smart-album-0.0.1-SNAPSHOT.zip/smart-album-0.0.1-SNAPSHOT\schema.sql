-- 创建数据库
CREATE DATABASE IF NOT EXISTS smart_album CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE smart_album;

-- 用户表
CREATE TABLE IF NOT EXISTS `user` (
    `id` BIGINT PRIMARY KEY AUTO_INCREMENT,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `password` VARCHAR(100) NOT NULL,
    `email` VARCHAR(100) NOT NULL UNIQUE,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 相册表
CREATE TABLE IF NOT EXISTS `album` (
    `id` BIGINT PRIMARY KEY AUTO_INCREMENT,
    `name` VARCHAR(100) NOT NULL,
    `description` TEXT,
    `user_id` BIGINT NOT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 图片表
CREATE TABLE IF NOT EXISTS `image` (
    `id` BIGINT PRIMARY KEY AUTO_INCREMENT,
    `name` VARCHAR(200) NOT NULL,
    `path` VARCHAR(500) NOT NULL,
    `url` VARCHAR(500) NOT NULL,
    `size` BIGINT NOT NULL,
    `width` INT NOT NULL,
    `height` INT NOT NULL,
    `format` VARCHAR(20) NOT NULL,
    `upload_time` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `album_id` BIGINT,
    `user_id` BIGINT NOT NULL,
    `ocr_processed` BOOLEAN DEFAULT FALSE,
    `ai_tagged` BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (`album_id`) REFERENCES `album`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 图片标签表
CREATE TABLE IF NOT EXISTS `image_tag` (
    `id` BIGINT PRIMARY KEY AUTO_INCREMENT,
    `image_id` BIGINT NOT NULL,
    `tag_name` VARCHAR(50) NOT NULL,
    `confidence` DOUBLE DEFAULT 1.0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`image_id`) REFERENCES `image`(`id`) ON DELETE CASCADE,
    UNIQUE KEY `uk_image_tag` (`image_id`, `tag_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- OCR识别结果表
CREATE TABLE IF NOT EXISTS `ocr_result` (
    `id` BIGINT PRIMARY KEY AUTO_INCREMENT,
    `image_id` BIGINT NOT NULL,
    `text_content` TEXT NOT NULL,
    `confidence` DOUBLE DEFAULT 1.0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`image_id`) REFERENCES `image`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 简历信息表
CREATE TABLE IF NOT EXISTS `resume_info` (
    `id` BIGINT PRIMARY KEY AUTO_INCREMENT,
    `image_id` BIGINT NOT NULL,
    `name` VARCHAR(100),
    `phone` VARCHAR(20),
    `email` VARCHAR(100),
    `skills` TEXT,
    `experience` TEXT,
    `education` TEXT,
    `extracted_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`image_id`) REFERENCES `image`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 插入测试数据
INSERT INTO `user` (`username`, `password`, `email`) VALUES 
('admin', '$2a$10$eAKw3yX3qV4a4V3a3qV4a4V3a3qV4a4V3a3qV4a4V3a3qV4a4V3a', 'admin@example.com');

INSERT INTO `album` (`name`, `description`, `user_id`) VALUES 
('默认相册', '系统默认相册', 1),
('个人照片', '个人生活照片', 1),
('工作文档', '工作相关的文档图片', 1);