package com.example.smartalbum.controller;

import com.example.smartalbum.entity.Album;
import com.example.smartalbum.entity.User;
import com.example.smartalbum.service.AlbumService;
import com.example.smartalbum.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/albums")
public class AlbumController {

    @Autowired
    private AlbumService albumService;
    
    @Autowired
    private UserService userService;

    private User getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        return userService.getUserByUsername(userDetails.getUsername());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Album> getAlbumById(@PathVariable Long id) {
        Album album = albumService.getAlbumById(id);
        return album != null ? ResponseEntity.ok(album) : ResponseEntity.notFound().build();
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Album>> getAlbumsByUserId(@PathVariable Long userId) {
        List<Album> albums = albumService.getAlbumsByUserId(userId);
        return ResponseEntity.ok(albums);
    }
    
    @GetMapping("/me")
    public ResponseEntity<List<Album>> getMyAlbums() {
        User currentUser = getCurrentUser();
        List<Album> albums = albumService.getAlbumsByUser(currentUser);
        return ResponseEntity.ok(albums);
    }
    
    @GetMapping("/me/public")
    public ResponseEntity<List<Album>> getMyPublicAlbums() {
        User currentUser = getCurrentUser();
        List<Album> albums = albumService.getPublicAlbumsByUser(currentUser);
        return ResponseEntity.ok(albums);
    }

    @PostMapping
    public ResponseEntity<Album> createAlbum(@RequestBody Album album) {
        User currentUser = getCurrentUser();
        Album createdAlbum = albumService.createAlbum(album, currentUser);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdAlbum);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Album> updateAlbum(@PathVariable Long id, @RequestBody Album album) {
        album.setId(id);
        boolean success = albumService.updateAlbum(album);
        return success ? ResponseEntity.ok(album) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAlbum(@PathVariable Long id) {
        boolean success = albumService.deleteAlbum(id);
        return success ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }
}