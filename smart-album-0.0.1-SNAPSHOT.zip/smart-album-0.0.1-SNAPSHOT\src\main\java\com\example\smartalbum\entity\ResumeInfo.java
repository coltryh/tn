package com.example.smartalbum.entity;

import lombok.Data;
import java.util.Date;

@Data
public class ResumeInfo {
    private Long id;
    private Long imageId;
    private String name;
    private String phone;
    private String email;
    private String skills;
    private String experience;
    private String education;
    private Date extractedAt;
}