package com.example.smartalbum.repository;

import com.example.smartalbum.entity.Album;
import com.example.smartalbum.entity.ShareLink;
import com.example.smartalbum.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Repository
public interface ShareLinkRepository extends JpaRepository<ShareLink, Long> {
    Optional<ShareLink> findByShareToken(String shareToken);
    List<ShareLink> findByAlbum(Album album);
    List<ShareLink> findByCreatedBy(User user);
    List<ShareLink> findByIsActiveTrue();
    List<ShareLink> findByExpireTimeBefore(Date date);
    boolean existsByShareToken(String shareToken);
}